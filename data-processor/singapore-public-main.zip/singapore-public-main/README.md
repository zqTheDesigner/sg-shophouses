# singapore-public
Various GIS layers regarding sites in Singapore.
To cite please note the metadata for each layer.
For a visualization of the layers see [https://nanyang-data.info/](https://nanyang-data.info/).
